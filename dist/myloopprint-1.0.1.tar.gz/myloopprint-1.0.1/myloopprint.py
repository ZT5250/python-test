"""
this is my first python3 code test
"""
def print_loop(datas,tabcount=0):
	for item in datas:
		if isinstance(item,list):
			print_loop(item,tabcount+1)
		else:
			for step in range(tabcount):
				print("\t",end='')
			print(item)