"""
this is my first python3 code test
"""
def print_loop(datas,indent=False,tabcount=0):
	for item in datas:
		if isinstance(item,list):
			print_loop(item,indent,tabcount+1)
		else:
			if indent:
				for step in range(tabcount):
					print("\t",end='')
			print(item)