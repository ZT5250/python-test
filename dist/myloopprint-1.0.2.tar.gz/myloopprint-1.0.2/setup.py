from distutils.core import setup

setup(
		name         = 'myloopprint',
		version      = '1.0.2',
		py_modules   = ['myloopprint'],
		author       = 'zhangtao',
		author_email = '15806111769@163.com',
		url          = 'https://github.com/ZT5250',
		description  = 'a simple printer of nested lists，add some code',
	)